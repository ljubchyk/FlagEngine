use axum::{
    Form, Router,
    extract::{Path, Query, State},
    response::{Html, Redirect},
    routing::{get, post},
};
use sailfish::Template;
use serde::Deserialize;
use time::OffsetDateTime;

use crate::{
    app_error::AppError::{self, FlagNotFound},
    domain::{DomainEvent, EventPayload, Flag},
    flag_repo::FlagFilter,
    http::AppState,
};

pub fn router() -> Router<AppState> {
    Router::new()
        .route("/admin", get(flags_page))
        .route("/admin/flags", post(create_flag))
        .route("/admin/flags/{key}/enable", post(enable_flag))
        .route("/admin/flags/{key}/disable", post(disable_flag))
        .route("/admin/flags/{key}/archive", post(archive_flag))
        .route("/admin/flags/{key}/audit", get(audit_flag))
}

fn format_utc(ms: i64) -> String {
    let Ok(dt) = OffsetDateTime::from_unix_timestamp_nanos(i128::from(ms) * 1_000_000) else {
        return ms.to_string();
    };

    format!(
        "{:04}-{:02}-{:02} {:02}:{:02}",
        dt.year(),
        u8::from(dt.month()),
        dt.day(),
        dt.hour(),
        dt.minute(),
    )
}

struct FlagView {
    key: String,
    enabled: bool,
    archived: bool,
    updated_at: String,
}

#[derive(Template)]
#[template(path = "flags.stpl")]
struct FlagsView {
    flags: Vec<FlagView>,
}

async fn flags_page(
    State(state): State<AppState>,
) -> Result<Html<String>, AppError> {
    let service = state.service.clone();

    let flags = tokio::task::spawn_blocking(move || service.find_flags(FlagFilter::All)).await??;

    let page = FlagsView {
        flags: flags.iter().map(|f| FlagView {
            key: f.key().to_owned(),
            enabled: f.is_enabled(),
            archived: f.is_archived(),
            updated_at: format_utc(f.updated_at()),
        }).collect(),
    };
    Ok(Html(page.render()?))
}

#[derive(Deserialize)]
struct CreateForm {
    key: String,
}

async fn create_flag(
    State(state): State<AppState>,
    Form(form): Form<CreateForm>,
) -> Result<Redirect, AppError> {
    let service = state.service.clone();

    tokio::task::spawn_blocking(move || service.create_flag(form.key, "admin".to_owned()))
        .await??;

    Ok(Redirect::to("/admin"))
}

async fn enable_flag(
    State(state): State<AppState>,
    Path(key): Path<String>,
) -> Result<Redirect, AppError> {
    let service = state.service.clone();
    tokio::task::spawn_blocking(move || service.enable_flag(key, "admin".to_owned())).await??;
    Ok(Redirect::to("/admin"))
}

async fn disable_flag(
    State(state): State<AppState>,
    Path(key): Path<String>,
) -> Result<Redirect, AppError> {
    let service = state.service.clone();
    tokio::task::spawn_blocking(move || service.disable_flag(key, "admin".to_owned())).await??;
    Ok(Redirect::to("/admin"))
}

async fn archive_flag(
    State(state): State<AppState>,
    Path(key): Path<String>,
) -> Result<Redirect, AppError> {
    let service = state.service.clone();
    tokio::task::spawn_blocking(move || service.archive_flag(key, "admin".to_owned())).await??;
    Ok(Redirect::to("/admin"))
}

#[derive(Deserialize)]
struct AuditQuery {
    before: Option<i64>,
}

struct EventView {
    actor: String,
    action: &'static str,
    created_at: String,
}

#[derive(Template)]
#[template(path = "audit.stpl")]
struct AuditView {
    flag: Flag,
    events: Vec<EventView>,
    next_before: Option<i64>,
}

async fn audit_flag(
    State(state): State<AppState>,
    Path(key): Path<String>,
    Query(query): Query<AuditQuery>,
) -> Result<Html<String>, AppError> {
    let service = state.service.clone();

    let (flag, audit) = tokio::task::spawn_blocking(move || {
        let flag = service
            .find_flag(&key)?
            .ok_or_else(|| FlagNotFound(key.clone()))?;

        let audit = service.find_audit(&key, query.before, 20)?;

        Ok::<_, AppError>((flag, audit))
    })
    .await??;

    let action = |e: &DomainEvent| match e.payload {
        EventPayload::FlagCreated { .. } => "Created",
        EventPayload::FlagEnabled => "Enabled",
        EventPayload::FlagDisabled => "Disabled",
        EventPayload::FlagArchived => "Archived",
    };

    let page = AuditView {
        flag,
        events: audit
            .events
            .iter()
            .map(|e| EventView {
                actor: e.actor.clone(),
                action: action(e),
                created_at: format_utc(e.occurred_at),
            })
            .collect(),
        next_before: audit.next_before,
    };
    Ok(Html(page.render()?))
}
